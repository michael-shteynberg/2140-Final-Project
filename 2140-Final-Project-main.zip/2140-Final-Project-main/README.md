End-to-end symmetric encryption tool made by:

- Jack Sprague
- Ben Yaker
- Michael Shteynberg